import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Todo } from './entity/todo.entity';
import { TodoModule } from './modules/todo.module';
import { TodoService } from './services/todo.service';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: 'localhost',
      port: 3306,
      username: 'root',
      password: '4567',
      database: 'todo-list',
      entities: [Todo],
      synchronize: true,
    }),
    TodoModule,
  ],
  providers: [AppService, TodoService],
  controllers: [AppController],
})
export class AppModule {}
