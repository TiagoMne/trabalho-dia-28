import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Todo } from '../entity/todo.entity';

@Injectable()
export class TodoService {
  constructor(
    @InjectRepository(Todo)
    private todoRepository: Repository<Todo>,
  ) {}

  async findAll(): Promise<Todo[]> {
    return this.todoRepository.find();
  }

  async findOne(id: number): Promise<Todo | null> {
    return this.todoRepository.findOneBy({ id });
  }

  async remove(id: number): Promise<void> {
    await this.todoRepository.delete(id);
  }

  async create(details: string, order: number): Promise<Todo | null> {
    const todo = await this.todoRepository.create({ details, order });
    return this.todoRepository.save(todo);
  }

  async changeStatus(id: number, status: boolean): Promise<Todo> {
    const todo = await this.todoRepository.findOneBy({
      id: id,
    });
    return this.todoRepository.save({ ...todo, status });
  }

  async editTodo(id: number, details: string): Promise<Todo> {
    const todo = await this.todoRepository.findOneBy({
      id: id,
    });

    return this.todoRepository.save({ ...todo, details });
  }
}
