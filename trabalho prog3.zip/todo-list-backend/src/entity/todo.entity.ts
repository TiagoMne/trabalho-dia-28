import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class Todo {
  @PrimaryGeneratedColumn('increment')
  id: number;

  @Column()
  order: number;

  @Column()
  details: string;

  @Column({ default: false })
  status: boolean;
}
