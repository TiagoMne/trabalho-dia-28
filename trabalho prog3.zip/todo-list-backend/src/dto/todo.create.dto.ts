import { IsNotEmpty } from 'class-validator';

export class CreateTodoDTO {
  @IsNotEmpty()
  details: string;

  @IsNotEmpty()
  order: number;
}
