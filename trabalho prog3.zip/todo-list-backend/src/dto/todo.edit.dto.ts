import { IsNotEmpty } from 'class-validator';

export class EditTodoDTO {
  @IsNotEmpty()
  details: string;
}
