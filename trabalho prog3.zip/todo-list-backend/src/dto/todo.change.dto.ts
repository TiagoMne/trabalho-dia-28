import { IsNotEmpty } from 'class-validator';

export class ChangeTodoDTO {
  @IsNotEmpty()
  status: boolean;
}
