import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
} from '@nestjs/common';
import { AppService } from './app.service';
import { Todo } from './entity/todo.entity';
import { CreateTodoDTO } from './dto/todo.create.dto';
import { ChangeTodoDTO } from './dto/todo.change.dto';
import { EditTodoDTO } from './dto/todo.edit.dto';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get('/')
  getTodos(): Promise<Todo[]> {
    return this.appService.getTodos();
  }

  @Get('/:id')
  getTodo(@Param('id') id: number): Promise<Todo> {
    return this.appService.getTodo(id);
  }

  @Post('/')
  createTodo(@Body() createTodoDto: CreateTodoDTO): object {
    return this.appService.createTodo(
      createTodoDto.details,
      createTodoDto.order,
    );
  }

  @Delete('/:id')
  deleteTodo(@Param('id') id: number): any {
    return this.appService.deleteTodo(id);
  }

  @Put('/status/:id')
  changeTodoStatus(
    @Param('id') id: number,
    @Body() changeTodoDto: ChangeTodoDTO,
  ): object {
    return this.appService.changeTodoStatus(id, changeTodoDto.status);
  }

  @Put('/:id')
  editTodo(@Param('id') id: number, @Body() editTodoDto: EditTodoDTO): object {
    return this.appService.editTodo(id, editTodoDto.details);
  }
}
