import { Injectable } from '@nestjs/common';
import { TodoService } from './services/todo.service';
import { Todo } from './entity/todo.entity';

@Injectable()
export class AppService {
  constructor(private todoService: TodoService) {}

  async getTodos(): Promise<Todo[] | null> {
    return await this.todoService.findAll();
  }

  async getTodo(id: number): Promise<Todo> {
    return await this.todoService.findOne(id);
  }

  async createTodo(details: string, order: number): Promise<Todo> {
    return await this.todoService.create(details, order);
  }

  async deleteTodo(id: number): Promise<any> {
    return await this.todoService.remove(id);
  }

  async changeTodoStatus(id: number, status: boolean): Promise<Todo> {
    return await this.todoService.changeStatus(id, status);
  }

  async editTodo(id: number, details: string): Promise<Todo> {
    return await this.todoService.editTodo(id, details);
  }
}
