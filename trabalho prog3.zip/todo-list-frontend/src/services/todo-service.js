import axios from "axios";
const instance = axios.create({
  baseURL: "http://localhost:3000",
});

export async function getTodos() {
  return instance.get("/");
}

export async function getTodo(id) {
  return instance.get(`/${id}`);
}

export async function createTodo(details, order) {
  return instance.post("/", {
    details,
    order,
  });
}

export async function deleteTodo(id) {
  return instance.delete(`/${id}`);
}

export async function updateTodoStatus(id, status) {
  return instance.put(`/status/${id}`, {
    status,
  });
}

export async function editTodo(id, details) {
  return instance.put(`/${id}`, {
    details,
  });
}
