<script setup>
import TodoItem from "./TodoItem.vue";
import DeleteTodo from "./DeleteTodo.vue";
import { ref } from "vue";
import axios from "axios";
import { store } from "../store/store";
import {
  getTodos,
  deleteTodo,
  updateTodoStatus,
} from "../services/todo-service";
import router from "../router";

const showModal = ref(null);
const selectedTodoId = ref(0);
const isSubmitting = ref(false);

async function fetchItems() {
  const response = await getTodos();
  store.setTodos(response.data);
}

function deleteTodoAction(id) {
  selectedTodoId.value = id;
  showModal.value.show();
}

async function deleteTodoModal(id) {
  isSubmitting.value = true;
  await deleteTodo(id);
  isSubmitting.value = false;
  showModal.value.close();
  await store.getTodos();
}

function editTodo(id) {
  router.push({
    path: `/editar/${id}`,
  });
}

async function changeTodoStatus(id, event) {
  try {
    const response = await updateTodoStatus(id, event.target.checked);
    if (response.status === 200) {
      fetchItems();
    }
  } catch (error) {}
}
</script>
<template>
  <main class="container-fluid text-center mt-2">
    <DeleteTodo
      :id="selectedTodoId"
      ref="showModal"
      @delete-item="deleteTodoModal"
      :is-submitting="isSubmitting"
    />
    <div class="container d-grid gap-3 mt-2">
      <div class="row">
        <div class="col-10">
          <h4>Lista de TODOs</h4>
        </div>
        <div class="col-2 d-flex justify-content-end">
          <button
            type="button"
            class="btn btn-success"
            @click="$router.push('/cadastro')"
          >
            Adicionar Item
          </button>
        </div>
      </div>
    </div>
    <div class="container d-grid gap-3 mt-2">
      <TodoItem
        v-for="item of store.todos"
        :key="item.id"
        :item="item"
        @edit-todo="editTodo"
        @delete-item="deleteTodoAction"
        @confirm-todo="confirmTodo"
        @change-todo-status="changeTodoStatus"
      />
    </div>
  </main>
</template>
