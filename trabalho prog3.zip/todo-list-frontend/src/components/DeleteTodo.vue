<script setup>
import { onMounted, ref } from "vue";
import { Modal } from "bootstrap";
defineProps({
  id: {
    type: Number,
    required: true,
  },
  isSubmitting: {
    type: Boolean,
    required: true,
  },
});
defineEmits(["deleteItem"]);

let modalEle = ref(null);
let thisModalObj = null;

onMounted(() => {
  thisModalObj = new Modal(modalEle.value);
});
function _show() {
  thisModalObj.show();
}
function _close() {
  thisModalObj.hide();
}
defineExpose({ show: _show, close: _close });
</script>

<template>
  <div
    class="modal fade"
    id="exampleModal"
    tabindex="-1"
    aria-labelledby=""
    aria-hidden="true"
    ref="modalEle"
  >
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Excluir Item</h5>
          <button
            type="button"
            class="btn-close"
            data-bs-dismiss="modal"
            aria-label="Close"
          ></button>
        </div>
        <div class="modal-body">
          <div>Deseja realmente deletar o item? #{{ id }}</div>
        </div>
        <div class="modal-footer">
          <button
            type="button"
            class="btn btn-secondary"
            data-bs-dismiss="modal"
            :disabled="isSubmitting"
          >
            Cancelar
          </button>
          <button
            type="button"
            class="btn btn-primary"
            @click="$emit('deleteItem', id)"
            :disabled="isSubmitting"
          >
            Sim, excluir
            <div
              class="spinner-border spinner-border-sm ms-2"
              role="status"
              v-if="isSubmitting"
            >
              <span class="visually-hidden">Loading...</span>
            </div>
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped></style>
