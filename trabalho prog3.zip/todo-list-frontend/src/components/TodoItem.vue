<script setup>
defineProps({
  item: {
    type: Object,
    required: true,
  },
});
defineEmits(["deleteItem", "editTodo", "confirmTodo"]);
</script>

<template>
  <div class="card">
    <div class="card-body">
      <div class="row d-flex align-items-center">
        <div class="col-1">
          <input
            type="checkbox"
            class="form-check-input"
            style="width: 32px; height: 32px"
            @change="$emit('changeTodoStatus', item.id, $event)"
            v-model="item.status"
          />
        </div>
        <div class="col-9">
          <lable class="text-center">{{ item.details }}</lable>
        </div>

        <div class="col-2 d-flex flex-column align-items-end gap-2">
          <button
            type="button"
            class="btn btn-sm btn-primary"
            @click="$emit('editTodo', item.id)"
          >
            <font-awesome-icon
              icon="fa-solid fa-edit"
              width="16px"
              height="16px"
            />
          </button>
          <button
            type="button"
            class="btn btn-sm btn-danger"
            @click="$emit('deleteItem', item.id)"
          >
            <font-awesome-icon
              icon="fa-solid fa-x"
              width="16px"
              height="16px"
            />
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
h1 {
  font-weight: 500;
  font-size: 2.6rem;
  position: relative;
  top: -10px;
}

h3 {
  font-size: 1.2rem;
}

.greetings h1,
.greetings h3 {
  text-align: center;
}

@media (min-width: 1024px) {
  .greetings h1,
  .greetings h3 {
    text-align: left;
  }
}
</style>
