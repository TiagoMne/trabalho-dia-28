<script setup>
import { ref, defineModel } from "vue";
import { store } from "../store/store";
import { createTodo, editTodo } from "../services/todo-service";
import { useRouter, useRoute } from "vue-router";
import { computed } from "@vue/reactivity";

computed({
  details: {
    get() {
      return this.details;
    },
    set(val) {
      this.details = val;
    },
  },
});

const router = useRouter();
const route = useRoute();

const createOrEdit = ref("create");
const editItem = ref(null);
const details = ref("");

if (route.params.id) {
  createOrEdit.value = "edit";
  const tmpItem = store.todos.find((t) => t.id === Number(route.params.id));
  editItem.value = tmpItem;
  details.value = tmpItem.details;
}

const isSubmitting = ref(false);

function changeDetails(value) {
  details.value = value;
}

async function submitModal() {
  isSubmitting.value = true;
  if (createOrEdit.value === "edit") {
    await editTodo(editItem.value.id, details.value);
  } else {
    let lastOrder = 1;
    if (store.todos.length > 0) {
      const lastTodo = store.todos[store.todos.length - 1];
      lastOrder = lastTodo.order;
    }
    try {
      await createTodo(details.value, lastOrder);
    } catch (error) {}
  }
  isSubmitting.value = false;
  await store.getTodos();
  router.push({ path: "/" });
}
</script>
<template>
  <div class="container-sm mt-2">
    <h4 class="text-center">
      <span v-if="createOrEdit === 'create'">Cadastrar TODO</span>
      <span v-if="createOrEdit === 'edit'">Editar TODO</span>
    </h4>
    <div class="card">
      <div class="card-body">
        <form @submit.prevent="submitModal(details)">
          <div class="mb-3">
            <label for="inputDetails" class="form-label">Descrição</label>
            <textarea
              id="inputDetails"
              class="form-control"
              :value="details"
              @change="changeDetails($event.target.value)"
              rows="3"
            />
          </div>
          <button
            type="submit"
            class="btn btn-primary"
            :disabled="isSubmitting"
            v-if="createOrEdit === 'edit'"
          >
            Salvar
            <div
              class="spinner-border spinner-border-sm ms-2"
              role="status"
              v-if="isSubmitting"
            >
              <span class="visually-hidden">Loading...</span>
            </div>
          </button>
          <button
            type="submit"
            class="btn btn-primary"
            :disabled="isSubmitting"
            v-if="createOrEdit === 'create'"
          >
            <span>Cadastrar</span>
            <div
              class="spinner-border spinner-border-sm ms-2"
              role="status"
              v-if="isSubmitting"
            >
              <span class="visually-hidden">Loading...</span>
            </div>
          </button>
        </form>
      </div>
    </div>
  </div>
</template>
