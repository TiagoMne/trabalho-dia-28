import { reactive } from "vue";
import { getTodos } from "../services/todo-service";

export const store = reactive({
  todos: [],
  setTodos(todos) {
    this.todos = todos;
  },
  async getTodos() {
    const response = await getTodos("/");
    this.todos = response.data;
  },
});
