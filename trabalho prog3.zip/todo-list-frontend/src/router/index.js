import { createRouter, createWebHashHistory } from "vue-router";

const routes = [
  {
    path: "/",
    name: "Home",
    component: () => import("../components/Home.vue"),
  },
  {
    path: "/cadastro",
    name: "Cadastro",
    component: () => import("../components/CreateItem.vue"),
  },
  {
    path: "/editar/:id",
    name: "Edição",
    component: () => import("../components/CreateItem.vue"),
  },
];

const router = createRouter({
  history: createWebHashHistory(),
  routes,
});

export default router;
